<?php
 session_start();
 
$hostname = 'localhost';       
 $dbname   = 'waterbilling';
 $username = 'root';            
 $password = '';       
 
 $conn=mysqli_connect($hostname, $username,"",$dbname);// or //DIE('NOT Connected!');
if($conn->connect_error)
    die("connection error".$conn->connect_error);
$login="SELECT * FROM user WHERE (username = '" .($_POST['username']) . "') and (password = '" .($_POST['password']) . "')";
$result=$conn->query($login);
// mysqli_select_db($conn,$dbname) or DIE('Database name is not available!');
// $login = mysqli_query($conn,"SELECT * FROM user WHERE (username = '" .($_POST['username']) . "') and (password = '" .($_POST['password']) . "')");
 $row=mysqli_fetch_array($result);  
 
 if($row){
 $_SESSION['id'] = $row['id'];

 echo '<script>windows: location="billing.php"</script>';
 }
	else {
		header ("location: index.php?err");
		}
 
 
?>
